class Post < ApplicationRecord
end